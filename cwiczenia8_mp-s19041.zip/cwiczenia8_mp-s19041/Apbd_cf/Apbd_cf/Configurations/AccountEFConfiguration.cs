﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Apbd_cf.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Apbd_cf.Configurations
{
    public class AccountEFConfiguration : IEntityTypeConfiguration<Account>
    {
        public void Configure(EntityTypeBuilder<Account> builder)
        {

            builder.HasKey(x => x.IdAccount).HasName("Account_pk");

            builder.Property(x => x.IdAccount).UseIdentityColumn();
            builder.Property(x => x.Login).HasMaxLength(100).IsRequired();
            builder.Property(x => x.Password).HasMaxLength(512).IsRequired();
            builder.Property(x=>x.Role).IsRequired();
            builder.Property(x=>x.RefreshToken).HasMaxLength(512).IsRequired();
            builder.Property(x=>x.RefreshTokenLife).IsRequired();


            var ac1 = new Account { IdAccount = 1, Login = "admin", Password = "admin", Role = "Admin", RefreshToken = Guid.NewGuid().ToString(), RefreshTokenLife = DateTime.Now.AddHours(2) };
            ac1.Password = new PasswordHasher<Account>().HashPassword(ac1, "admin");
            var ac2 = new Account { IdAccount = 2, Login = "jw", Password ="123123", Role = "Doctor", RefreshToken = Guid.NewGuid().ToString(), RefreshTokenLife = DateTime.Now.AddHours(2) };
            ac2.Password = new PasswordHasher<Account>().HashPassword(ac2, "123123");

            var accounts = new List<Account>
            {
                ac1,
                ac2
            };
            builder.HasData(accounts);
        }
    }
}
