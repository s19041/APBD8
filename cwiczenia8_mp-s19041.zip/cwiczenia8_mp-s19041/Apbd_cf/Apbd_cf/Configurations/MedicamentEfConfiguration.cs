﻿using Apbd_cf.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Configurations
{
    public class MedicamentEfConfiguration : IEntityTypeConfiguration<Medicament>
    {
        public void Configure(EntityTypeBuilder<Medicament> builder)
        {

            builder.HasKey(x => x.IdMedicament)
                     .HasName("Medicament_pk");

            builder.Property(x => x.IdMedicament).UseIdentityColumn();
            builder.Property(x => x.Name).HasMaxLength(100).IsRequired();
            builder.Property(x => x.Description).HasMaxLength(100).IsRequired();
            builder.Property(x => x.Type).HasMaxLength(100).IsRequired();

            var medicaments = new List<Medicament>
            {
                new Medicament{IdMedicament=1,Name="Ibuprofen",Description="Leczy",Type="Przeciwbólowy"},
                 new Medicament{IdMedicament=2,Name="WitaminaC Lewoskretna",Description="Nie Leczy",Type="Homeopatia"}
            };
            builder.HasData(medicaments);
        }
    }
}
