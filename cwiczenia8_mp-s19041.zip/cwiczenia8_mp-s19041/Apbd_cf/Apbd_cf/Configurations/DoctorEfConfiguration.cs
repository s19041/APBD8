﻿using Apbd_cf.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Configurations
{
    public class DoctorEfConfiguration : IEntityTypeConfiguration<Doctor>
    {
        public void Configure(EntityTypeBuilder<Doctor> builder)
        {

            builder.HasKey(x => x.IdDoctor).HasName("Doctor_pk");

            builder.Property(x => x.IdDoctor).UseIdentityColumn();
            builder.Property(x => x.FirstName).HasMaxLength(100).IsRequired();
            builder.Property(x => x.LastName).HasMaxLength(100).IsRequired();
            builder.Property(x => x.Email).HasMaxLength(100).IsRequired();

            var doctors = new List<Doctor>
            {
                new Doctor{IdDoctor=1,FirstName="Jakub",LastName="Wójcik",Email="jw@onet.pl"},
                 new Doctor{IdDoctor=2,FirstName="Jan",LastName="Nowak",Email="janN@onet.pl"}
            };
            builder.HasData(doctors);
        }
    }
}
