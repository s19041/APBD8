﻿using Apbd_cf.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Configurations
{
    public class PatientEfConfiguration : IEntityTypeConfiguration<Patient>
    {
        public void Configure(EntityTypeBuilder<Patient> builder)
        {

            builder.HasKey(x => x.IdPatient).HasName("Patient_pk");

            builder.Property(x => x.IdPatient).UseIdentityColumn();
            builder.Property(x => x.FirstName).HasMaxLength(100).IsRequired();
            builder.Property(x => x.LastName).HasMaxLength(100).IsRequired();
            builder.Property(x => x.Birthdate).IsRequired();

            var patients = new List<Patient>
            {
                new Patient{IdPatient=1,FirstName="Andrzej",LastName="Piaseczny",Birthdate=new DateTime(1971,1,6)},
                new Patient{IdPatient=2,FirstName="Halina",LastName="Nowakowska",Birthdate=new DateTime(1988,4,7)}
            };
            builder.HasData(patients);
        }
    }
}
