﻿using Apbd_cf.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Configurations
{
    public class PrescriptionEfConfiguration : IEntityTypeConfiguration<Prescription>
    {
        public void Configure(EntityTypeBuilder<Prescription> builder)
        {

            builder.HasKey(x => x.IdPrescription)
                    .HasName("Prescription_pk");

            builder.Property(x => x.IdPrescription).UseIdentityColumn();
            builder.Property(x => x.Date).IsRequired();
            builder.Property(x => x.DueDate).IsRequired();
            builder.Property(x => x.IdDoctor).IsRequired();
            builder.Property(x => x.IdPatient).IsRequired();

            builder.HasOne(x => x.IdDoctorNavigation)
                    .WithMany(x => x.Prescriptions)
                    .HasForeignKey(x => x.IdDoctor)
                    .HasConstraintName("Doctor_IdDoctorNavigation");

            builder.HasOne(x => x.IdPatientNavigation)
                    .WithMany(x => x.Prescriptions)
                    .HasForeignKey(x => x.IdPatient)
                    .HasConstraintName("Patient_IdPatientNavigation");

            var prescriptions = new List<Prescription>
            {
                new Prescription{IdPrescription=1,Date=new DateTime(2020,1,1),DueDate=DateTime.Now,IdPatient=1,IdDoctor=1}
            };
            builder.HasData(prescriptions);
        }
    }
}
