﻿using Apbd_cf.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Configurations
{
    public class PrescriptionMedicamentEfConfiguration : IEntityTypeConfiguration<PrescriptionMedicament>
    {
        public void Configure(EntityTypeBuilder<PrescriptionMedicament> builder)
        {

            builder.ToTable("Prescription_Medicament");
            builder.HasKey(e => new { e.IdMedicament, e.IdPrescription })
                .HasName("PrescriptionMedicament_pk");

            builder.HasOne(x => x.IdPrescriptionNavigation)
                .WithMany(x => x.PrescriptionMedicaments)
                .HasForeignKey(x => x.IdPrescription)
                .HasConstraintName("Prescription_PrescriptionNavigation");

            builder.HasOne(x => x.IdMedicamentNavigation)
                .WithMany(x => x.PrescriptionMedicaments)
                .HasForeignKey(x => x.IdMedicament)
                .HasConstraintName("Medicament_MedicamentNavigation")
                .OnDelete(DeleteBehavior.ClientSetNull);

            builder.Property(x => x.Details).HasMaxLength(100).IsRequired();

            var prescriptionMedicaments = new List<PrescriptionMedicament>
            {
                new PrescriptionMedicament{IdMedicament=1,IdPrescription=1,Dose=10,Details="Pana Andrzeja coś boli"}
            };
            builder.HasData(prescriptionMedicaments);
        }
    }
}
