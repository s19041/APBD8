﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Middlewares
{
    public class ExceptionMiddleware
    {
        

        private readonly RequestDelegate _next;
        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                HandleException(httpContext, ex);
            }
        }
        private async void HandleException(HttpContext httpcontext, Exception exception)
        {
            
            try
            {
                using StreamWriter file = new("log.txt", append: true);
                await file.WriteLineAsync(DateTime.Now+": "+exception.Message);

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
