﻿
using Microsoft.AspNetCore.Mvc;

using Apbd_cf.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Apbd_cf.Models;
using Apbd_cf.DTO.Requests;
using Microsoft.AspNetCore.Authorization;

namespace Apbd_cf.Controllers
{
    [Route("api/doctors")]
    [ApiController]
    [Authorize]
    public class DoctorsController : ControllerBase
    {
        private readonly IDoctorDbRepository _doctorDbRepository;
        public DoctorsController(IDoctorDbRepository doctorDbRepository)
        {
            _doctorDbRepository = doctorDbRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetDoctors()
        {
            var result = await _doctorDbRepository.GetDoctorsFromDbAsync();
            return Ok(result);
        }
        
        [HttpPost]
        public async Task<IActionResult> AddDoctor([FromBody] DoctorRequestDTO addDoctorRequest)
        {
            if(String.IsNullOrEmpty(addDoctorRequest.Email)|| String.IsNullOrEmpty(addDoctorRequest.FirstName)|| String.IsNullOrEmpty(addDoctorRequest.LastName))
                return BadRequest();
            var result = await _doctorDbRepository.AddDoctorToDbAsync(addDoctorRequest);
            if (result)
                return NoContent();
            return BadRequest();
        }
        [HttpDelete("{idDoctor}")]
        public async Task<IActionResult> DeleteDoctor([FromRoute] string idDoctor)
        {
            int id;
            if (!int.TryParse(idDoctor,out id))
                return BadRequest();
            var result = await _doctorDbRepository.DeleteDoctorInDbAsync(id);
            if (result)
                return NoContent();
            return NotFound();
        }
        [HttpPut("{idDoctor}")]
        public async Task<IActionResult> UpdateDoctor([FromRoute] string idDoctor,[FromBody] DoctorRequestDTO updateDoctorRequest)
        {
            if (String.IsNullOrEmpty(updateDoctorRequest.Email) || String.IsNullOrEmpty(updateDoctorRequest.FirstName) || String.IsNullOrEmpty(updateDoctorRequest.LastName))
                return BadRequest();
            int id;
            if (!int.TryParse(idDoctor, out id))
                return BadRequest();
            var result = await _doctorDbRepository.UpdateDoctorInDbAsync(id, updateDoctorRequest);
            if (result)
                return NoContent();
            return NotFound();
        }
    }
}
