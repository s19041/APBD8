﻿using Apbd_cf.DTO.Requests;
using Apbd_cf.DTO.Responses;
using Apbd_cf.Models;
using Apbd_cf.Repositories.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Apbd_cf.Controllers
{
    [Route("api/account")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly IAccountDbRepository _accountDbRepositor;
        private readonly IConfiguration _configuration;
        public AccountsController(IAccountDbRepository accountDbRepositor, IConfiguration configuration)
        {
            _accountDbRepositor = accountDbRepositor;
            _configuration = configuration;
        }
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login(AccountRequestDTO account)
        {

            
            var acc = await _accountDbRepositor.LoginAsync(account);
            if (acc == null)
                return BadRequest();
            var verifyPassword = new PasswordHasher<Account>().VerifyHashedPassword(acc, acc.Password, account.password);
            if(verifyPassword==PasswordVerificationResult.Failed)
                return BadRequest();
            var token = GenerateToken(acc);

            var refToken = await _accountDbRepositor.UpdateRefreshToken(acc);
            return Ok(new TokenResponseDTO
            {
                appToken = new JwtSecurityTokenHandler().WriteToken(token),
                refreshToken = refToken
            });

        }
        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenRequestDTO refreshTokenDTO)
        {
            var acc = await _accountDbRepositor.GetAccForRefreshTokenAsync(refreshTokenDTO.RefreshToken);
            if (acc == null)
                return BadRequest();
            var token = GenerateToken(acc);
            var refToken = await _accountDbRepositor.UpdateRefreshToken(acc);
            return Ok(new TokenResponseDTO
            {
                appToken = new JwtSecurityTokenHandler().WriteToken(token),
                refreshToken = refToken
            });
        }
        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequestDTO registerDTO)
        {
            if(String.IsNullOrEmpty(registerDTO.login)|| String.IsNullOrEmpty(registerDTO.password)||String.IsNullOrEmpty(registerDTO.role))
                return BadRequest();
            var res = await _accountDbRepositor.RegisterNewAccAsync(registerDTO);
            if (res)
                return Ok();
            return BadRequest();
        }




        private JwtSecurityToken GenerateToken(Account acc)
        {
            Claim[] claims =
            {
                new Claim(ClaimTypes.NameIdentifier, acc.IdAccount.ToString()),
                new Claim(ClaimTypes.Name, acc.Login),
                new Claim(ClaimTypes.Role,acc.Role),
            };


            SymmetricSecurityKey key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Secret"]));
            SigningCredentials creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            JwtSecurityToken token = new JwtSecurityToken(
                issuer: "http://localhost:5000",
                audience: "http://localhost:5000",
                claims: claims,
                expires: DateTime.Now.AddMinutes(10),
                signingCredentials: creds
            );
            return token;
        }
        
        
    }
}
