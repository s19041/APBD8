﻿using Apbd_cf.Repositories.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Controllers
{
    [Route("api/prescriptions")]
    [ApiController]
    [Authorize]
    public class PrescriptionsController : ControllerBase
    {
        private readonly IPrescriptionDbRepository _prescriptionDbRepository;
        public PrescriptionsController(IPrescriptionDbRepository prescriptionDbRepository)
        {
            _prescriptionDbRepository = prescriptionDbRepository;
        }
        [HttpGet("{idPrescription}")]
        public async Task<IActionResult> GetPrescription([FromRoute] string idPrescription)
        {
            int id;
            if (!int.TryParse(idPrescription, out id))
                return BadRequest();
            var result = await _prescriptionDbRepository.GetPrescriptionFromDbAsync(id);
            if (result == null)
                return NotFound();
            return Ok(result);
        }

    }
}
