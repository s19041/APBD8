﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Apbd_cf.DTO;
using Apbd_cf.DTO.Requests;
using Apbd_cf.Repositories.Implementations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Apbd_cf.DTO.Responses;

namespace Apbd_cf.Repositories.Interfaces
{
    public interface IPrescriptionDbRepository
    {
        Task<PrescriptionResponseDTO> GetPrescriptionFromDbAsync(int id);
    }
}
