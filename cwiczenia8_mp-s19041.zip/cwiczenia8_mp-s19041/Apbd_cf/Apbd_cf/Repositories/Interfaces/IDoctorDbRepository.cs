﻿using Apbd_cf.DTO;
using Apbd_cf.DTO.Requests;
using Apbd_cf.Repositories.Implementations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Repositories.Interfaces
{
    public interface IDoctorDbRepository
    {
        Task<ICollection<DoctorResponseDto>> GetDoctorsFromDbAsync();
        Task<bool> AddDoctorToDbAsync(DoctorRequestDTO addDoctorRequest);
        Task<bool> UpdateDoctorInDbAsync(int IdDoctor, DoctorRequestDTO updateDoctorRequest);
        Task<bool> DeleteDoctorInDbAsync(int IdDoctor);
    }
}
