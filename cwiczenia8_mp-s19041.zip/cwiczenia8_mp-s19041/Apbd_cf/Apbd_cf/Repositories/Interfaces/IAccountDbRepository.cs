﻿using Apbd_cf.DTO.Requests;
using Apbd_cf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Repositories.Interfaces
{
    public interface IAccountDbRepository
    {
        Task<Account> LoginAsync(AccountRequestDTO addDoctorRequest);
        Task<string> UpdateRefreshToken(Account account);
        Task<Account> GetAccForRefreshTokenAsync(string refreshToken);
        Task<bool> RegisterNewAccAsync(RegisterRequestDTO registerDTO);
    }
}
