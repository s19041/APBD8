﻿using Apbd_cf.DTO;
using Apbd_cf.DTO.Responses;
using Apbd_cf.Models;
using Apbd_cf.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Repositories.Implementations
{
    public class PrescriptionDbRepository : IPrescriptionDbRepository
    {
        private readonly PrescriptionContext _context;
        public PrescriptionDbRepository(PrescriptionContext context)
        {
            _context = context;
        }
        public async Task<PrescriptionResponseDTO> GetPrescriptionFromDbAsync(int id)
        {
            var res = await _context.Prescription.Include(x => x.PrescriptionMedicaments)
                .ThenInclude(x => x.IdMedicamentNavigation).Where(x=>x.IdPrescription==id)
                .Select(x => new PrescriptionResponseDTO
                {
                    MedicamentsList = x.PrescriptionMedicaments.Select(x => new MedicamentResponseDTO { Name = x.IdMedicamentNavigation.Name, Dose = x.Dose, Details = x.Details }).ToList(),
                    Doctor = new DoctorResponseDto { FirstName = x.IdDoctorNavigation.FirstName, LastName = x.IdDoctorNavigation.LastName, Email = x.IdDoctorNavigation.Email },
                    Patient =new PatientResponseDTO { FirstName = x.IdPatientNavigation.FirstName, LastName = x.IdPatientNavigation.LastName },
                    Date = x.Date,
                    DueDate = x.DueDate
                }).SingleOrDefaultAsync();
            return res;
        }
    }
}
