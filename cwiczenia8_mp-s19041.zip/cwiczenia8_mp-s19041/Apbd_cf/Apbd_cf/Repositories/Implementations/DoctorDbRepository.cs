﻿using Apbd_cf.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Apbd_cf.Models;
using Apbd_cf.DTO;
using Microsoft.EntityFrameworkCore;
using Apbd_cf.DTO.Requests;

namespace Apbd_cf.Repositories.Implementations
{
    public class DoctorDbRepository : IDoctorDbRepository
    {
        private readonly PrescriptionContext _context;
        public DoctorDbRepository(PrescriptionContext context)
        {
            _context = context;
        }
        public async Task<ICollection<DoctorResponseDto>> GetDoctorsFromDbAsync()
        {
            var res = await _context.Doctor.Select(x => new DoctorResponseDto
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                Email = x.Email
            }).ToListAsync();
            return res;
        }
        public async Task<bool> AddDoctorToDbAsync(DoctorRequestDTO addDoctorRequest)
        {
            var doctorFromDb = await _context.Doctor.SingleOrDefaultAsync(x => x.Email == addDoctorRequest.Email);
            if (doctorFromDb != null)
                return false;


            var newDoctor = await _context.AddAsync(new Doctor
            {
                FirstName=addDoctorRequest.FirstName,
                LastName=addDoctorRequest.LastName,
                Email=addDoctorRequest.Email

            });
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteDoctorInDbAsync(int IdDoctor)
        {
            var doctorFromDb = await _context.Doctor.SingleOrDefaultAsync(x => x.IdDoctor == IdDoctor);
            if (doctorFromDb == null)
                return false;
            _context.Remove(doctorFromDb);
            return await _context.SaveChangesAsync() > 0;
        }
        public async Task<bool> UpdateDoctorInDbAsync(int IdDoctor, DoctorRequestDTO updateDoctorRequest)
        {
            var doctorFromDb = await _context.Doctor.SingleOrDefaultAsync(x => x.IdDoctor == IdDoctor);
            if (doctorFromDb == null)
                return false;
            doctorFromDb.FirstName = updateDoctorRequest.FirstName;
            doctorFromDb.LastName = updateDoctorRequest.LastName;
            doctorFromDb.Email = updateDoctorRequest.Email;
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
