﻿using Apbd_cf.DTO.Requests;
using Apbd_cf.Models;
using Apbd_cf.Repositories.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.Repositories.Implementations
{
    public class AccountDbRepository : IAccountDbRepository
    {
        private readonly PrescriptionContext _context;
        public AccountDbRepository(PrescriptionContext context)
        {
            _context = context;
        }

        public async Task<Account> GetAccForRefreshTokenAsync(string refreshToken)
        {
            var res = await _context.Account.SingleOrDefaultAsync(x => x.RefreshToken == refreshToken && DateTime.Compare(x.RefreshTokenLife, DateTime.Now) > 0);
            return res;
        }

        public async Task<Account> LoginAsync(AccountRequestDTO account)
        {
            var res = await _context.Account.SingleOrDefaultAsync(x => x.Login == account.login);
           
            return res;
        }

        public async Task<bool> RegisterNewAccAsync(RegisterRequestDTO registerDTO)
        {
            var account = new Account {
                Login = registerDTO.login,
                Password = registerDTO.password,
                Role = registerDTO.role,
                RefreshToken = Guid.NewGuid().ToString(),
                RefreshTokenLife = DateTime.Now.AddHours(2) };
            account.Password= new PasswordHasher<Account>().HashPassword(account, account.Password);

            await _context.AddAsync(account);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<string> UpdateRefreshToken(Account account)
        {
            var token= Guid.NewGuid().ToString();
            var acc = await _context.Account.SingleAsync(x => x.IdAccount == account.IdAccount);
            acc.RefreshToken = token;
            acc.RefreshTokenLife = DateTime.Now.AddHours(2);
            await _context.SaveChangesAsync();
            return token;
        }
    }
}
