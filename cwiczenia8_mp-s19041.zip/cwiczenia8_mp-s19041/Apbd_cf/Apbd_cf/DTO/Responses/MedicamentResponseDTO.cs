﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.DTO.Responses
{
    public class MedicamentResponseDTO
    {
        public string Name { get; set; }
        public int Dose { get; set; }
        public string Details { get; set; }

    }
}
