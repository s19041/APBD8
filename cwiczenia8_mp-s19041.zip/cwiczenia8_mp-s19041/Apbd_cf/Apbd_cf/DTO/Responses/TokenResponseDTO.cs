﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.DTO.Responses
{
    public class TokenResponseDTO
    {
        public string appToken { get; set; }
        public string refreshToken { get; set; }

    }
}
