﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.DTO.Responses
{
    public class PrescriptionResponseDTO
    {
        public List<MedicamentResponseDTO> MedicamentsList { get; set; }

        public DoctorResponseDto Doctor { get; set; }
        public PatientResponseDTO Patient { get; set; }
        public DateTime Date { get; set; }
        public DateTime DueDate { get; set; }
    }
}
