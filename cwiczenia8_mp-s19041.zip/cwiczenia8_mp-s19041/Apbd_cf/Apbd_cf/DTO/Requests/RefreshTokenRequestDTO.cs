﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apbd_cf.DTO.Requests
{
    public class RefreshTokenRequestDTO
    {
        public string RefreshToken { get; set; }
    }
}
